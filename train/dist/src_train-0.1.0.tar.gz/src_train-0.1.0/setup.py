# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src_train']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'src-train',
    'version': '0.1.0',
    'description': 'utils for train and save the model',
    'long_description': '',
    'author': 'ValHdez',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
